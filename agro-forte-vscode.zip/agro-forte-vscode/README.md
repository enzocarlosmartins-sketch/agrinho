# Agro Forte Futuro Sustentável - Website

Um site moderno e responsivo sobre agricultura sustentável, equilibrando produção agrícola com preservação ambiental.

## 📋 Estrutura do Projeto

```
agro-forte-vscode/
├── index.html          # Arquivo HTML principal
├── css/
│   └── style.css       # Estilos CSS
├── js/
│   └── script.js       # Scripts JavaScript
├── images/             # Pasta para imagens locais
└── README.md           # Este arquivo
```

## 🎨 Paleta de Cores

- **Verde Escuro (Primário)**: `#1B4332`
- **Verde Médio (Secundário)**: `#2D6A4F`
- **Verde Claro (Acento)**: `#D8F3DC`
- **Branco (Fundo)**: `#FFFFFF`

## 🚀 Como Usar

### 1. Abrir no VS Code

1. Abra o VS Code
2. Vá em `File` → `Open Folder`
3. Selecione a pasta `agro-forte-vscode`
4. Clique em `Select Folder`

### 2. Visualizar o Site

#### Opção 1: Live Server (Recomendado)
1. Instale a extensão "Live Server" no VS Code
2. Clique com botão direito em `index.html`
3. Selecione "Open with Live Server"
4. O site abrirá automaticamente no navegador

#### Opção 2: Abrir Diretamente
1. Clique com botão direito em `index.html`
2. Selecione "Open with Default Browser"

#### Opção 3: Via Terminal
```bash
# Se tiver Python instalado
python -m http.server 8000

# Ou com Node.js
npx http-server
```

### 3. Editar o Código

- **HTML**: Edite `index.html` para adicionar/remover seções
- **CSS**: Edite `css/style.css` para alterar estilos
- **JavaScript**: Edite `js/script.js` para adicionar funcionalidades

## 📱 Responsividade

O site é totalmente responsivo e funciona em:
- ✅ Desktop (1200px+)
- ✅ Tablet (768px - 1199px)
- ✅ Mobile (até 767px)

## 🔧 Funcionalidades

### Implementadas
- ✅ Navegação fixa e responsiva
- ✅ Smooth scroll para links internos
- ✅ Animações de entrada ao scroll
- ✅ Contadores de estatísticas animados
- ✅ Efeitos hover nos cards
- ✅ Lazy loading de imagens
- ✅ Design responsivo

### Para Adicionar
- 📝 Formulário de contato funcional
- 🔍 Busca de conteúdo
- 💬 Chat de suporte
- 📧 Newsletter
- 🗺️ Mapa interativo

## 📝 Seções do Site

1. **Navegação**: Menu principal com links para seções
2. **Hero**: Seção de boas-vindas com CTA
3. **Desafio Global**: Contexto do problema global
4. **Equilíbrio Perfeito**: Três pilares da sustentabilidade
5. **Tecnologias**: Inovações agrícolas modernas
6. **Práticas Regenerativas**: Estratégias comprovadas
7. **Impacto Brasil**: Estatísticas de sucesso
8. **Biodiversidade**: Importância da conservação
9. **Futuro do Agro**: Visão inspiradora
10. **CTA**: Chamada para ação
11. **Footer**: Informações de rodapé

## 🎯 Customização

### Alterar Cores
Edite as variáveis CSS em `css/style.css`:

```css
:root {
    --primary-dark: #1B4332;      /* Verde escuro */
    --primary-medium: #2D6A4F;    /* Verde médio */
    --primary-light: #D8F3DC;     /* Verde claro */
    --background: #FFFFFF;        /* Branco */
    --text-dark: #1B4332;         /* Texto escuro */
    --text-medium: #2D6A4F;       /* Texto médio */
}
```

### Alterar Fontes
Edite o link do Google Fonts em `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=FONTE1:wght@400;700&family=FONTE2:wght@400;700&display=swap" rel="stylesheet">
```

### Adicionar Imagens Locais
1. Coloque as imagens na pasta `images/`
2. Altere o `src` da imagem no HTML:

```html
<img src="images/sua-imagem.jpg" alt="Descrição">
```

## 🔗 Links de Imagens

As imagens do site são carregadas de um CDN externo. Para usar imagens locais:

1. Baixe as imagens
2. Coloque na pasta `images/`
3. Altere os `src` no `index.html`

## 📚 Recursos Utilizados

- **Fontes**: Google Fonts (Playfair Display, Lato)
- **Ícones**: Font Awesome 6.0
- **CSS**: CSS3 com Grid e Flexbox
- **JavaScript**: Vanilla JavaScript (sem dependências)

## 🌐 Deploy

### Opção 1: Netlify
1. Faça upload da pasta no Netlify
2. Configure o build (não necessário para site estático)
3. Deploy automático

### Opção 2: GitHub Pages
1. Crie um repositório no GitHub
2. Faça push dos arquivos
3. Ative GitHub Pages nas configurações

### Opção 3: Vercel
1. Conecte seu repositório ao Vercel
2. Faça deploy com um clique

## 🐛 Troubleshooting

### Imagens não carregam
- Verifique a URL da imagem
- Certifique-se de que o CDN está acessível
- Use imagens locais como alternativa

### Estilos não aparecem
- Limpe o cache do navegador (Ctrl+Shift+Delete)
- Verifique se o arquivo CSS está na pasta correta
- Recarregue a página (Ctrl+R ou Cmd+R)

### JavaScript não funciona
- Abra o console (F12) e procure por erros
- Verifique se o arquivo JS está na pasta correta
- Certifique-se de que não há conflitos com outras bibliotecas

## 📞 Suporte

Para dúvidas ou sugestões, entre em contato através do formulário no site.

## 📄 Licença

Este projeto é livre para uso e modificação.

---

**Desenvolvido com ❤️ para um futuro sustentável**
