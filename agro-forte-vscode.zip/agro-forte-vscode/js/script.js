/* ============================================
   AGRO FORTE FUTURO SUSTENTÁVEL - JavaScript
   Funcionalidades de interatividade
   ============================================ */

// Smooth scroll para links de navegação
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animação de entrada de elementos ao scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Aplicar observador aos elementos
document.querySelectorAll('.pillar, .practice-card, .tech-item, .stat-box, .bio-item, .future-pillar').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// Navbar sticky com efeito de sombra
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 5px 20px rgba(27, 67, 50, 0.15)';
    } else {
        navbar.style.boxShadow = '0 2px 10px rgba(27, 67, 50, 0.1)';
    }
});

// Contador de estatísticas com animação
function animateCounter(element, target, duration = 2000) {
    let current = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Iniciar contadores quando visíveis
const statBoxes = document.querySelectorAll('.stat-number');
let countersStarted = false;

const counterObserver = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting && !countersStarted) {
            countersStarted = true;
            statBoxes.forEach(box => {
                const text = box.textContent.trim();
                let target = 0;
                
                // Extrair número do texto
                if (text.includes('M')) {
                    target = parseInt(text) * 1000000;
                } else if (text.includes('B')) {
                    target = parseInt(text) * 1000000000;
                } else if (text.includes('K')) {
                    target = parseInt(text) * 1000;
                } else if (text.includes('x')) {
                    target = parseInt(text);
                } else if (text.includes('%')) {
                    target = parseInt(text);
                }
                
                if (target > 0) {
                    animateCounter(box, target);
                }
            });
        }
    });
}, { threshold: 0.5 });

const statsSection = document.querySelector('.stats-grid');
if (statsSection) {
    counterObserver.observe(statsSection);
}

// Adicionar classe ativa ao menu durante scroll
window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').slice(1) === current) {
            link.classList.add('active');
        }
    });
});

// Adicionar estilos para link ativo
const style = document.createElement('style');
style.textContent = `
    .nav-menu a.active {
        color: var(--primary-dark);
        border-bottom-color: var(--primary-light);
    }
`;
document.head.appendChild(style);

// Efeito de hover nos cards
document.querySelectorAll('.pillar, .practice-card, .tech-item, .bio-item, .future-pillar').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-10px)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Lazy loading de imagens
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
}

// Função para enviar formulário (exemplo para futura integração)
function handleFormSubmit(e) {
    e.preventDefault();
    console.log('Formulário enviado');
    // Aqui você pode adicionar lógica para enviar dados
}

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    console.log('Agro Forte Futuro Sustentável - Site carregado com sucesso!');
    
    // Adicionar event listeners aos botões
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', function() {
            console.log('Botão clicado:', this.textContent);
        });
    });
});

// Função para abrir modal (exemplo)
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

// Função para fechar modal
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Fechar modal ao clicar fora dele
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Função para enviar email (requer backend)
async function sendEmail(formData) {
    try {
        const response = await fetch('/api/send-email', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            console.log('Email enviado com sucesso!');
            return true;
        } else {
            console.error('Erro ao enviar email');
            return false;
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        return false;
    }
}

// Função para rastrear eventos (Google Analytics, etc)
function trackEvent(category, action, label) {
    if (typeof gtag !== 'undefined') {
        gtag('event', action, {
            'event_category': category,
            'event_label': label
        });
    }
}

// Exportar funções para uso global
window.agroForte = {
    openModal,
    closeModal,
    sendEmail,
    trackEvent
};
